**Corn Maze by Rebeca Rodriguez**

You find yourself at a pumkin farm during a brisk September day. As you walk around you spot a corn maze. You feel this strong urge to go in. Is this maze all that is seems?

Helpful commands:

cd: to see where you are located

To add, it would be very helpful to look at the hints throughout the maze! They provide very useful information.